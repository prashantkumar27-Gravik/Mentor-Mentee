import React, { useState, useEffect } from 'react';
import axios from 'axios';

function EditProfile({ userId }) {
  const [userData, setUserData] = useState({
    name: '',
    bio: '',
    skills: '',
    linkedin: '',
  });

  useEffect(() => {
    // Fetch user data when component mounts
    axios
      .get(`http://localhost:5000/api/users/${userId}`)
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching user data:', error);
      });
  }, [userId]);

  const handleChange = (e) => {
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:5000/api/users/${userId}`, userData)
      .then((response) => {
        alert('Profile updated successfully!');
      })
      .catch((error) => {
        console.error('Error updating profile:', error);
      });
  };

  return (
    <div>
      <h2>Edit Profile</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={userData.name}
          onChange={handleChange}
        />

        <label>Bio:</label>
        <textarea
          name="bio"
          value={userData.bio}
          onChange={handleChange}
        />

        <label>Skills (comma-separated):</label>
        <input
          type="text"
          name="skills"
          value={userData.skills}
          onChange={handleChange}
        />

        <label>LinkedIn Profile:</label>
        <input
          type="text"
          name="linkedin"
          value={userData.linkedin}
          onChange={handleChange}
        />

        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
}

export default EditProfile;
