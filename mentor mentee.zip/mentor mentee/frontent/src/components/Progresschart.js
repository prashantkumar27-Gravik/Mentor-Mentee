import React from 'react';
import { Line } from 'react-chartjs-2';

function ProgressChart({ goals }) {
  const data = {
    labels: goals.map((goal, index) => `Goal ${index + 1}`),
    datasets: [
      {
        label: 'Goal Completion Progress',
        data: goals.map((goal) => goal.progress),
        borderColor: 'rgba(75,192,192,1)',
        backgroundColor: 'rgba(75,192,192,0.2)',
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
      },
    },
  };

  return (
    <div>
      <h2>Mentorship Progress Tracker</h2>
      <Line data={data} options={options} />
    </div>
  );
}

export default ProgressChart;
