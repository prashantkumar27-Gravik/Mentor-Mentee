import React from 'react';
import ProgressChart from './components/ProgressChart';
import EditProfile from './components/EditProfile';
import Chat from './components/Chat';

function App() {
  const goals = [
    { progress: 30 },
    { progress: 60 },
    { progress: 90 },
  ];

  const userId = 'some-user-id'; // Example user ID

  return (
    <div>
      <h1>Welcome to MentorConnect</h1>
      <EditProfile userId={userId} />
      <ProgressChart goals={goals} />
      <Chat />
    </div>
  );
}

export default App;
